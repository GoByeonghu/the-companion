package com.gobyeonghu.the_companion;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //declare variable for xml component
    TextView Text_id, Text_time, Text_gps, Text_vector, Text_wifi, Text_direction;
    Button Button_detect, Button_delete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("동행 (test ver)");

        Text_id = (TextView) findViewById(R.id.text_id);
        Text_time = (TextView) findViewById(R.id.text_time);
        Text_gps = (TextView) findViewById(R.id.text_gps);
        Text_vector = (TextView) findViewById(R.id.text_vector);
        Text_wifi = (TextView) findViewById(R.id.text_wifi);
        Text_direction = (TextView) findViewById(R.id.text_direction);

        Button_detect = (Button) findViewById(R.id.button_detect);
        Button_delete = (Button) findViewById(R.id.button_delete);

        //click detect button event
        Button_detect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {




                Text_id.setText("gobyeonghu");
                Text_time.setText("gobyeonghu");
                Text_gps.setText("gobyeonghu");
                Text_vector.setText("gobyeonghu");
                Text_wifi.setText("gobyeonghu");
                Text_direction.setText("gobyeonghu");

                Text_id.setVisibility(View.VISIBLE);
                Text_time.setVisibility(View.VISIBLE);
                Text_gps.setVisibility(View.VISIBLE);
                Text_vector.setVisibility(View.VISIBLE);
                Text_wifi.setVisibility(View.VISIBLE);
                Text_direction.setVisibility(View.VISIBLE);
            }
        });

        //click delete button event
        Button_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Text_id.setVisibility(View.INVISIBLE);
                Text_time.setVisibility(View.INVISIBLE);
                Text_gps.setVisibility(View.INVISIBLE);
                Text_vector.setVisibility(View.INVISIBLE);
                Text_wifi.setVisibility(View.INVISIBLE);
                Text_direction.setVisibility(View.INVISIBLE);
            }
        });
    }
}